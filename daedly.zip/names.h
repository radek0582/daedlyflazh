#include "deklaracje.h"

#define				_ISLAMIC_NAMES_AMOUNT		10
#define				_CHRISTIAN_NAMES_AMOUNT		30

char *islamic_names_list [] = {	"Ashira", "Avigail", "Rachel", "Yasmin", "Gavriela", "Naomi", "Sara", "Devorah", "Miriam", "Ester"};

char *christian_names_list [] = {"Aaron", "Alexander", "Zachariah", "Ulysses", "Tristan", "Titus", "Samuel", "Ruben", "Rafael", "Nathan",
											"Marco", "Malakai", "Josue", "Jacob", "Isaiah", "Immanuel", "Humberto", "Elias", "Duncan", "Dominic",
                                 "David", "Cornelius", "Arthur", "Abel", "Josef", "Jared", "Uriel", "Isaac", "Hector", "Leo"};

